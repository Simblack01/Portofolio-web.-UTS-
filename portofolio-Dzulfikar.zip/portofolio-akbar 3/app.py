import os, sqlite3, secrets
from functools import wraps
from flask import Flask, render_template, request, jsonify, redirect, url_for, g, Response

app = Flask(__name__)
DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "portfolio.db")
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASS = os.getenv("ADMIN_PASSWORD", "admin123")

# Edit data ini sesuai profil kamu
PROFILE = dict(
    name="AKBAR DZULFIKAR WICAKSONO",
    address="Magelang, Jawa Tengah, Indonesia",
    campus="Universitas Nahdlatul Ulama Yogyakarta",
    prodi="S1 Informatika",
    hobby="Mendaki gunung",
    links=[("Instagram", "@dzulfikar.ws", "https://www.instagram.com/dzulfikar.ws"),
           ("GitHub", "@simblack01", "https://github.com/Simblack01"), ("TikTok", "@simblack", "https://www.tiktok.com/@simblackedet_")],
)

SEED = [
    ("education", "S1 Informatika", "Universitas Nahdlatul Ulama Yogyakarta", "2025 - Sekarang", "Mempelajari pemrograman web, basis data, dan kecerdasan buatan.", 0),
    ("education", "SMA / SMK", "SMK Alhusain", "2019 - 2022", "Jurusan TKJ.", 0),
    ("education", "SMP / Mts", "SMP Alhusain", "2016 - 2019", "",0),
    ("education", "SD / MI", "MI Al-Hidayah", "2010 - 2016", "",0),
    ("experience", "Teknisi Komputer", "Nuzulia Komputer", "2025", "melakukan servis serta bongkar pasang komputer dan laptop.", ""),
    ("skill", "Python", "Backend", "", "", 85), ("skill", "Flask", "Backend", "", "", 80),
    ("skill", "HTML & CSS", "Frontend", "", "", 85), ("skill", "JavaScript", "Frontend", "", "", 75),
    ("skill", "SQL", "Database", "", "", 70),
]

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB); g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close(_):
    d = g.pop("db", None)
    if d: d.close()

def init_db():
    c = sqlite3.connect(DB)
    c.executescript("""
    CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY, category TEXT, title TEXT, subtitle TEXT, period TEXT, description TEXT, level INTEGER DEFAULT 0);
    CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, name TEXT, email TEXT, message TEXT, is_read INTEGER DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP);""")
    if not c.execute("SELECT 1 FROM items").fetchone():
        c.executemany("INSERT INTO items(category,title,subtitle,period,description,level) VALUES(?,?,?,?,?,?)", SEED)
    c.commit(); c.close()

def auth(f):
    @wraps(f)
    def w(*a, **k):
        c = request.authorization
        ok = c and secrets.compare_digest(c.username, ADMIN_USER) and secrets.compare_digest(c.password or "", ADMIN_PASS)
        return f(*a, **k) if ok else Response("Login diperlukan", 401, {"WWW-Authenticate": 'Basic realm="Admin"'})
    return w

@app.route("/")
def index():
    items = {c: db().execute("SELECT * FROM items WHERE category=? ORDER BY id", (c,)).fetchall()
             for c in ("education", "experience", "skill")}
    return render_template("index.html", p=PROFILE, items=items)

# CREATE pesan dari form kontak
@app.post("/api/messages")
def create_message():
    d = request.get_json(silent=True) or request.form
    n, e, m = (d.get(k, "").strip() for k in ("name", "email", "message"))
    if not (n and "@" in e and m):
        return jsonify(ok=False, error="Isi nama, email yang valid, dan pesan."), 400
    db().execute("INSERT INTO messages(name,email,message) VALUES(?,?,?)", (n[:80], e[:120], m[:2000])); db().commit()
    return jsonify(ok=True)

# ---------- ADMIN (CRUD) ----------
@app.route("/admin")
@auth
def admin():
    return render_template("admin.html",
        items=db().execute("SELECT * FROM items ORDER BY category,id").fetchall(),
        messages=db().execute("SELECT * FROM messages ORDER BY id DESC").fetchall())

FIELDS = ("category", "title", "subtitle", "period", "description", "level")

def item_vals():
    f = request.form
    try: lv = max(0, min(100, int(f.get("level", 0) or 0)))
    except ValueError: lv = 0
    return [f.get("category", "skill"), f.get("title", ""), f.get("subtitle", ""), f.get("period", ""), f.get("description", ""), lv]

@app.post("/admin/items/add")
@auth
def item_add():
    db().execute("INSERT INTO items(category,title,subtitle,period,description,level) VALUES(?,?,?,?,?,?)", item_vals()); db().commit()
    return redirect(url_for("admin"))

@app.post("/admin/items/<int:i>/update")
@auth
def item_update(i):
    db().execute("UPDATE items SET category=?,title=?,subtitle=?,period=?,description=?,level=? WHERE id=?", item_vals() + [i]); db().commit()
    return redirect(url_for("admin"))

@app.post("/admin/items/<int:i>/delete")
@auth
def item_delete(i):
    db().execute("DELETE FROM items WHERE id=?", (i,)); db().commit()
    return redirect(url_for("admin"))

@app.post("/admin/messages/<int:i>/toggle")
@auth
def msg_toggle(i):
    db().execute("UPDATE messages SET is_read=1-is_read WHERE id=?", (i,)); db().commit()
    return redirect(url_for("admin"))

@app.post("/admin/messages/<int:i>/delete")
@auth
def msg_delete(i):
    db().execute("DELETE FROM messages WHERE id=?", (i,)); db().commit()
    return redirect(url_for("admin"))

init_db()
if __name__ == "__main__":
    app.run(debug=True)

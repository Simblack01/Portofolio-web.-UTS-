# Portofolio Akbar Dzulfikar Wicaksono (Flask)

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py                   # buka http://127.0.0.1:5000
```
Admin CRUD: http://127.0.0.1:5000/admin (default `admin` / `admin123`, ganti lewat env `ADMIN_USER` & `ADMIN_PASSWORD`).
Data profil (alamat, kampus, link sosmed) diedit di `PROFILE` di `app.py`.

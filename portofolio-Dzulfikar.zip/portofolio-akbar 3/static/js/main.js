gsap.registerPlugin(ScrollTrigger);
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const nav=$('#nav'),links=$$('#nav a'),pill=$('#pill'),mascot=$('#mascot'),word=$('#word'),wf=$('#wf'),zt=$('#zoomTrack'),welcome=$('#welcome');

/* ===== scroll halus (inersia) ===== */
const lenis=new Lenis({lerp:.07,wheelMultiplier:.9});
lenis.on('scroll',ScrollTrigger.update);
gsap.ticker.add(t=>lenis.raf(t*1000));gsap.ticker.lagSmoothing(0);
links.forEach(a=>a.addEventListener('click',e=>{e.preventDefault();const h=a.getAttribute('href');
  lenis.scrollTo(h==='#home'?0:h,{duration:2.2,easing:t=>1-Math.pow(1-t,4)})}));
gsap.to('#bar',{scaleX:1,ease:'none',scrollTrigger:{start:0,end:'max',scrub:.3}});

/* ===== judul hero dipecah per huruf ===== */
welcome.innerHTML=['WELCOME TO MY','PORTOFOLIO'].map(l=>`<div class="ln">${l.split(' ').map(w=>`<span class="w">${[...w].map(c=>`<i class="ch">${c}</i>`).join('')}</span>`).join('<span class="sp"></span>')}</div>`).join('');

/* ===== intro saat load ===== */
gsap.set(nav,{xPercent:-50,x:0,y:-130});
gsap.timeline({defaults:{ease:'power3.out'}})
  .to('.curtain',{opacity:0,duration:1.6,onComplete:()=>$('.curtain').remove()})
  .from('.trees-wrap',{scale:1.4,opacity:0,duration:2.4},0)
  .to(nav,{y:0,duration:1.3,ease:'back.out(1.5)'},.9);

/* ===== HERO: scrub dengan easing ===== */
gsap.timeline({scrollTrigger:{trigger:'#home',start:'top top',end:'bottom bottom',scrub:1.5}})
  .fromTo('#bg',{scale:1},{scale:1.14,ease:'none',duration:1.2},0)
  .fromTo('#dim',{opacity:.55},{opacity:0,ease:'none',duration:1.2},0)
  .to('#trees',{scale:2.9,rotation:2.5,opacity:0,ease:'power2.in',duration:.9},0)
  .to('.hint',{opacity:0,duration:.1},0)
  .fromTo('.welcome .ch',{yPercent:130,rotation:9},{yPercent:0,rotation:0,stagger:.02,ease:'power3.out',duration:.3},.3)
  .to('.welcome',{scale:1.18,opacity:0,ease:'power2.in',duration:.25},1.05);


/* ===== ABOUT ===== */
gsap.set('.hobby',{rotation:3});
const aT={trigger:'#about',start:'top 55%'};
gsap.from('.name i',{yPercent:115,rotation:7,duration:1.2,stagger:.13,ease:'power4.out',scrollTrigger:aT});
gsap.from('.meta li',{x:-50,opacity:0,duration:.9,stagger:.12,delay:.5,ease:'power3.out',scrollTrigger:aT});
gsap.fromTo('.about-photo img',{yPercent:16,scale:.86,opacity:0},{yPercent:0,scale:1,opacity:1,ease:'none',scrollTrigger:{trigger:'#about',start:'top bottom',end:'top 15%',scrub:1.3}});
gsap.to('.about-photo img',{y:-60,ease:'none',scrollTrigger:{trigger:'#about',start:'top top',end:'bottom top',scrub:1.2}});
gsap.from('.hobby',{x:280,rotation:26,opacity:0,duration:1.5,ease:'back.out(1.15)',scrollTrigger:{trigger:'#about',start:'top 45%'}});
gsap.to('.hf',{y:-14,duration:2.6,yoyo:true,repeat:-1,ease:'sine.inOut'});
gsap.fromTo('#ghost',{xPercent:0},{xPercent:-48,ease:'none',scrollTrigger:{trigger:'#about',start:'top bottom',end:'bottom top',scrub:1}});

/* ===== ZOOM ke huruf O ===== */
let zp=0;
function setOrigin(){const t=$('.target');gsap.set(word,{transformOrigin:`${t.offsetLeft+t.offsetWidth*.1}px ${t.offsetTop+t.offsetHeight*.5}px`})}
gsap.from('.word span',{yPercent:110,opacity:0,duration:1.1,stagger:.07,ease:'power4.out',scrollTrigger:{trigger:zt,start:'top 65%'}});
gsap.timeline({scrollTrigger:{trigger:zt,start:'top top',end:'bottom bottom',scrub:1.4,onUpdate:s=>{zp=s.progress;theme()}}})
  .to(word,{scale:130,ease:'power3.in',duration:1},0)
  .to(wf,{opacity:1,ease:'power1.in',duration:.25},.72);

/* ===== PORTFOLIO (tabs) ===== */
gsap.set('.card',{opacity:0});
const enter=p=>gsap.fromTo(p.querySelectorAll('.card'),{y:90,opacity:0,rotationX:-16,transformPerspective:800},{y:0,opacity:1,rotationX:0,duration:1,stagger:.12,ease:'power3.out',clearProps:'transformPerspective'});
const pc={trigger:'#portfolio-content',start:'top 60%'};
gsap.from('#portfolio-content .sec-title',{y:90,opacity:0,duration:1.2,ease:'power4.out',scrollTrigger:pc});
gsap.from('.tabs',{y:60,opacity:0,scale:.9,duration:1,delay:.15,ease:'back.out(1.4)',scrollTrigger:pc});
ScrollTrigger.create({trigger:'#portfolio-content',start:'top 45%',once:true,onEnter:()=>enter($('.panel.on'))});
$$('.tabs button').forEach(b=>b.onclick=()=>{if(b.classList.contains('on'))return;
  $$('.tabs button,.panel').forEach(x=>x.classList.remove('on'));b.classList.add('on');
  const p=$('#p-'+b.dataset.tab);p.classList.add('on');enter(p)});
$$('.arrow').forEach(a=>a.onclick=()=>a.parentElement.querySelector('.track').scrollBy({left:(a.classList.contains('r')?1:-1)*480,behavior:'smooth'}));
$$('.track').forEach(tr=>{let d=0,sx,sl;
  tr.addEventListener('pointerdown',e=>{if(e.pointerType==='touch')return;d=1;sx=e.clientX;sl=tr.scrollLeft;tr.style.scrollSnapType='none'});
  addEventListener('pointermove',e=>{if(d)tr.scrollLeft=sl-(e.clientX-sx)});
  addEventListener('pointerup',()=>{if(d){d=0;tr.style.scrollSnapType=''}})});

/* ===== CONTACT ===== */
gsap.from('#contact .sec-title',{y:90,opacity:0,duration:1.2,ease:'power4.out',scrollTrigger:{trigger:'#contact',start:'top 60%'}});
gsap.from('.box',{y:130,opacity:0,rotationX:-9,transformPerspective:900,duration:1.3,stagger:.2,ease:'power4.out',scrollTrigger:{trigger:'.contact-grid',start:'top 82%'}});
gsap.from('.social',{x:-40,opacity:0,duration:.8,stagger:.1,ease:'power3.out',scrollTrigger:{trigger:'.contact-grid',start:'top 60%'}});
const toast=m=>{const t=$('#toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),3200)};
$('#cform').onsubmit=async e=>{e.preventDefault();const f=e.target,btn=f.querySelector('button');btn.disabled=true;
  try{const r=await fetch('/api/messages',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(Object.fromEntries(new FormData(f)))});
    const d=await r.json();if(d.ok){f.reset();toast('Pesan terkirim. Terima kasih!')}else toast(d.error)}catch{toast('Gagal mengirim. Coba lagi.')}
  btn.disabled=false};

/* ===== NAV: pill + maskot elastis ===== */
let active='',cur='home';
function place(a,instant){const d=instant?0:.8;
  gsap.to(pill,{left:a.offsetLeft,width:a.offsetWidth,duration:d,ease:'power4.inOut'});
  gsap.to(mascot,{left:a.offsetLeft+a.offsetWidth/2-22,duration:d,ease:'power4.inOut'});
  if(!instant)gsap.fromTo(mascot,{scaleX:1.2,scaleY:.8},{scaleX:1,scaleY:1,duration:1,delay:.5,ease:'elastic.out(1,.4)'})}
function theme(){nav.classList.toggle('light',cur==='about'||cur==='contact'||(cur==='portfolio'&&zp>.85))}
function setSec(n){cur=n;theme();if(n!==active){active=n;links.forEach(l=>l.classList.toggle('on',l.dataset.t===n));place($(`#nav a[data-t=${n}]`))}}
[['home','#home'],['about','#about'],['portfolio','#portfolio'],['contact','#contact']].forEach(([n,s])=>
  ScrollTrigger.create({trigger:s,start:'top 50%',end:'bottom 50%',onToggle:t=>t.isActive&&setSec(n)}));
lenis.on('scroll',({velocity:v})=>gsap.to('.sec-title,.name',{skewY:Math.max(-6,Math.min(6,v*.22)),duration:.6,ease:'power3.out',overwrite:'auto'}));

/* tilt 3D (hanya saat hover kartu) */
$$('.tilt').forEach(el=>{
  el.addEventListener('pointermove',e=>{const r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
    gsap.to(el,{rotationY:x*16,rotationX:-y*16,transformPerspective:800,duration:.5,ease:'power2.out',overwrite:'auto'})});
  el.addEventListener('pointerleave',()=>gsap.to(el,{rotationX:0,rotationY:0,duration:1,ease:'elastic.out(1,.5)',overwrite:'auto'}))});

/* ===== init ===== */
function fit(){setOrigin();place($(`#nav a[data-t=${active||'home'}]`),true)}
addEventListener('resize',fit);
document.fonts.ready.then(()=>{fit();setSec('home');ScrollTrigger.refresh()});
addEventListener('load',()=>ScrollTrigger.refresh());

/* ===== SNAP per scene: berhenti rapi di titik scene, tidak kebablasan ===== */
let snapT,dir=1,snapping=false;
const topOf=el=>el.getBoundingClientRect().top+scrollY;
function stops(){const h=$('#home');
  return [0,topOf(h)+.76*(h.offsetHeight-innerHeight),topOf($('#about')),topOf(zt),topOf($('#portfolio-content')),topOf($('#contact'))]}
function snap(){
  if(snapping)return;
  if(lenis.isScrolling){snapT=setTimeout(snap,100);return}
  const s=stops(),y=scrollY;
  if(y>=s[4])return;                       // area konten & contact: scroll bebas
  let i=0;while(i<s.length-2&&y>=s[i+1])i++;
  const a=s[i],b=s[i+1],f=(y-a)/(b-a);
  const t=dir>0?(f>.18?b:a):(f<.82?a:b);   // searah scroll: lanjut kalau sudah >18%
  if(Math.abs(t-y)<2)return;
  snapping=true;
  lenis.scrollTo(t,{duration:1.1,easing:x=>1-Math.pow(1-x,3),onComplete:()=>{snapping=false}});
}
lenis.on('scroll',({velocity:v})=>{if(Math.abs(v)>.05)dir=v>0?1:-1;clearTimeout(snapT);if(!snapping)snapT=setTimeout(snap,130)});
